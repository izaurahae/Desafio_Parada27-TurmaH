var cpf = document.getElementById("i_cpf");

function cpf_mask(){
    cpf.value = cpf.value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
}